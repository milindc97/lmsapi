module.exports = {
    HOST: "", // username:password@cluster.49s.mongodb.net
    PORT: 27017,
    DB: "" // Database Name
  };