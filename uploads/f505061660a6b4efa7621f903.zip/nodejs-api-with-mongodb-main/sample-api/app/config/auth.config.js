module.exports = {
    secret: "secret-key",
    jwtExpiration: 1296000,           // 15 days
    jwtRefreshExpiration: 86400
};