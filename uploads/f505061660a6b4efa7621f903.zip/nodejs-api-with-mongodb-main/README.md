# Sample Nodejs Api With Mongodb
* User auth added
* JWT Authorisation
* nodemon support

# Steps
1. Clone
2. Run npm install
3. Change database config
4. Run npm start
